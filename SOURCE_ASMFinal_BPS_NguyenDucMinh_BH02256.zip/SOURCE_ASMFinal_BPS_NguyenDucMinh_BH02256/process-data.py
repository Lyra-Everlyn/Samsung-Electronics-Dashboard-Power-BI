import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.linear_model import LinearRegression
import warnings

# Disable unnecessary warnings
warnings.filterwarnings('ignore')

# =============================================================================
# Step 1
# =============================================================================
# 1. Loading all data sources
try:
    df_trans = pd.read_csv('transactions.csv')
    df_prod = pd.read_csv('products.csv')
    df_cat = pd.read_csv('product_categories.csv')
    df_cust = pd.read_csv('customers.csv')
    df_sensors = pd.read_csv('machine_sensors.csv')
except Exception as e:
    print(f"Error loading files: {e}")

# =============================================================================
# Step 2
# =============================================================================

# 2. Handling Missing Values
df_trans['Quantity'] = df_trans['Quantity'].fillna(df_trans['Quantity'].median())
df_trans['UnitPrice'] = df_trans['UnitPrice'].fillna(df_trans['UnitPrice'].median())
df_trans['TotalAmount'] = df_trans['Quantity'] * df_trans['UnitPrice']

# 3. Data Type Conversion
df_trans['SaleDate'] = pd.to_datetime(df_trans['SaleDate'])
df_sensors['timestamp'] = pd.to_datetime(df_sensors['timestamp'])

# 4. Merging Master Transaction Data
master_df = df_trans.merge(df_prod[['ProductID', 'ProductName', 'ProductGroupID']], on='ProductID', how='left')
master_df = master_df.merge(df_cat[['ProductGroupID', 'GroupName']], on='ProductGroupID', how='left')
master_df = master_df.merge(df_cust[['CustomerID', 'CustomerName']], on='CustomerID', how='left')

print("Success: Initial Data Cleaning and Merging complete (Error Fixed).")



# =============================================================================
# Step 3 PREDICTIVE MODELING (REVENUE FORECASTING)
# =============================================================================
print("\n--- Step 3: Predictive Modeling (Revenue Forecasting) ---")

# Aggregating revenue by date for the model
daily_rev = master_df.groupby('SaleDate')['TotalAmount'].sum().reset_index().sort_values('SaleDate')
daily_rev['day_index'] = np.arange(len(daily_rev))

# Train Linear Regression Model
X = daily_rev[['day_index']]
y = daily_rev['TotalAmount']
model = LinearRegression()
model.fit(X, y)

# Generate Predictions
daily_rev['PredictedRevenue'] = model.predict(X)

# [NEW FEATURE]: Merge Predictions back into Master Data for Power BI Page 1
master_df = master_df.merge(daily_rev[['SaleDate', 'PredictedRevenue']], on='SaleDate', how='left')

print("Success: Sales Forecast calculated and merged into Master Dataset.")

# =============================================================================
# MACHINE HEALTH ANALYSIS (IoT DATA)
# =============================================================================
print("\n--- Step 4: IoT Sensor Analysis for Maintenance ---")

# [NEW FEATURE]: Detailed Machine Metrics for Power BI Page 3
# We identify machines with high temperature or 'Warning' status
machine_health = df_sensors.groupby('machine_id').agg({
    'sensor_temperature': 'mean',
    'sensor_vibration': 'max',
    'status': lambda x: (x == 'Warning').sum()
}).rename(columns={'status': 'WarningCount'}).reset_index()

# Create a Maintenance Alert flag (1 for Alert, 0 for Normal)
# This allows 'Conditional Formatting' in Power BI
machine_health['MaintenanceAlert'] = np.where((machine_health['sensor_temperature'] > 80) | (machine_health['WarningCount'] > 0), 1, 0)

# Export for Dashboard Page 3
machine_health.to_csv('samsung_machine_health.csv', index=False)

print("Success: Machine health metrics exported to 'samsung_machine_health.csv'.")

# =============================================================================
# STEP 5: VISUALIZATION & FINAL EXPORT
# =============================================================================
print("\n--- Step 5: Visualizing Results & Exporting to Power BI ---")

# Create a Professional 4-Chart Analysis
fig, axes = plt.subplots(2, 2, figsize=(16, 10))
plt.subplots_adjust(hspace=0.4)

# Chart 1: Actual vs Predicted Revenue
axes[0, 0].plot(daily_rev['SaleDate'], daily_rev['TotalAmount'], label='Actual Sales', color='#0078D4')
axes[0, 0].plot(daily_rev['SaleDate'], daily_rev['PredictedRevenue'], label='Predicted Trend', color='red', linestyle='--')
axes[0, 0].set_title('Revenue Forecasting Trend', fontweight='bold')
axes[0, 0].legend()

# Chart 2: Top Products by Quantity
top_products = master_df.groupby('ProductName')['Quantity'].sum().sort_values(ascending=False).head(5)
sns.barplot(x=top_products.values, y=top_products.index, ax=axes[0, 1], palette='viridis')
axes[0, 1].set_title('Top 5 Products for Inventory Priority', fontweight='bold')

# Chart 3: Revenue by Region
regional_sales = master_df.groupby('Region')['TotalAmount'].sum()
axes[1, 0].pie(regional_sales, labels=regional_sales.index, autopct='%1.1f%%', startangle=140)
axes[1, 0].set_title('Revenue Distribution by Region', fontweight='bold')

# Chart 4: Sensor Temperature Histogram
sns.histplot(df_sensors['sensor_temperature'], kde=True, ax=axes[1, 1], color='orange')
axes[1, 1].set_title('Factory Temperature Distribution', fontweight='bold')

plt.show()

# Final Export for Power BI Page 1 & 2
master_df.to_csv('samsung_cleaned_master.csv', index=False)
print("Success: Final Master File 'samsung_cleaned_master.csv' is ready.")

# =============================================================================
# STEP 6: BUSINESS RECOMMENDATIONS
# =============================================================================
print("\n--- STEP 6: RECOMMENDATIONS FOR OPERATION DIRECTOR ---")
slope = model.coef_[0]

print(f"1. FORECASTING: Revenue trend is " + ("INCREASING" if slope > 0 else "STABLE/DECREASING") + f" (Slope: {slope:.2f}).")
print(f"2. MAINTENANCE: {machine_health['MaintenanceAlert'].sum()} machines require urgent inspection (See Page 3).")
print("3. INVENTORY: Prioritize top products identified in Step 5 to minimize stockouts.")

print("\n--- Process Complete ---")